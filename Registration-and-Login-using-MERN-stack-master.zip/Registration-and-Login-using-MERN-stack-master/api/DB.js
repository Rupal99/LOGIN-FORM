module.exports = {
    DB: 'mongodb://localhost/catapultSports'
}