const RouteNames = {
    register: '/register',
    login: '/login',
    data: '/allData',
    validate: '/validateUsername'

};

module.exports = RouteNames;